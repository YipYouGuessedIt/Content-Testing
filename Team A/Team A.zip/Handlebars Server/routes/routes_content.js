/**
 * Created by Paul Engelke (13093500) on 2015/04/10.
 *
 * This file contains the routing for the content integration demo.
 */

/**
 * This function appends new HTTP request handlers to the router.
 * @type {Function}
 */
exports = module.exports = function(router, resources, reporting, status, threads){

    var formidable = require('formidable');
    var bodyparser = require('body-parser');
    var urlencodedparser = bodyparser.urlencoded({extended:false});

    // RESOURCES ------------------------------------------------------

    var renderConstraints = function(res, err, results){

        if (err){

            res.render('error', {
                message : "No data could be retrieved",
                error : err
            });
        } else {

            results.forEach(function(con){ // set unit to MB
                con.mb_size = (con.size_limit/(1024*1024)).toFixed(3);
            });

            var object = {};
            object.title = "Constraint Management";
            object.constraints = results;
            res.render('content/manageConstraints', object);
        }
    };

    var renderResources = function(res, err, results){

        if (err) {
            res.render('error', {
                message: "No data could be retrieved",
                error: err
            });
        } else if (results.length == 0){
            res.render('error', {
                message: "There are no resources."
            });
        } else {

            var object = {};
            object.files = results;
            res.render('content/manageResources', object);
        }
    };

    router.get('/addPost', function(req, res){

        res.render('content/addPost', {
            title : "New Post"
        });
    });

    router.get('/addConstraint', function(req, res){

        res.render('content/addConstraint', {
            title : "New Constraint"
        });
    });

    router.get('/manageConstraints', function(req, res){

        resources.getConstraints(function(err, results){
            renderConstraints(res, err, results);
        });
    });

    router.get('/manageResources', function(req, res){

        resources.getResourcesRelated(null, function(err, results){
           renderResources(res, err, results);
        });
    });

    router.post('/submitPost', function(req, res){

        var form = new formidable.IncomingForm();
        form.parse(req, function(err, fields, files){

            resources.uploadResources(files, 0, function(success){
                if (!success){

                    res.render('error', {
                        message : "Resources could not be uploaded."
                    });
                } else {

                    resources.getResourcesAll(function(err, results){
                        renderResources(res, err, results);
                    });
                }
            });
        });
    });

    router.post('/removeResource', urlencodedparser, function(req, res){

        resources.removeResource(req.body._id, function(success){
            if (!success){

                res.render('error', {
                    message : "Resource could not be deleted."
                });
            } else {

                resources.getResourcesAll(function(err, results){
                    renderResources(res, err, results);
                });
            }
        });
    });

    router.post('/submitConstraint', urlencodedparser, function(req, res){

        resources.addConstraint(req.body.mime_type, req.body.size_limit, function(success){
           if (!success){

               res.render('error', {
                   message : "Constraint could not be added.",
                   error : {}
               });
           } else {

               resources.getConstraints(function(err, results){

                    renderConstraints(res, err, results);
               });
           }
        });
    });

    router.post('/requestConstraintUpdate', urlencodedparser, function(req, res){

        res.render('content/updateConstraint', {
            title : "Updating A Constraint",
            constraintID : req.body._id,
            mime_type : req.body.mime_type,
            size_limit : req.body.size_limit
        });
    });

    router.post('/updateConstraint', urlencodedparser, function(req, res){

        resources.updateConstraint(req.body._id, req.body.size_limit, function(success){
            if (!success){

                res.render('error', {
                    message : "Constraint could not be updated.",
                    error : {}
                });
            } else {

                resources.getConstraints(function(err, results){

                    renderConstraints(res, err, results);
                });
            }
        });
    });

    router.post('/removeConstraint', urlencodedparser, function(req, res){

        resources.removeConstraint(req.body._id, function(success){
            if (!success){

                res.render('error', {
                    message : "Constraint could not be removed.",
                    error : {}
                });
            } else {

                resources.getConstraints(function(err, results){

                    renderConstraints(res, err, results);
                });
            }
        });
    });

    // REPORTING ------------------------------------------------------

    router.get('/reports', function(req, res, next){

        res.render('content/reportsMainsVersion', {
            title : 'Reporting'
        });
    });

    router.post('/downloadreport', urlencodedparser, function(req, res,next){

        // do something
        console.log(req.body);

        switch(req.body.reportType)
        {

            case 'subTypeStudents':
            {
                reporting.getStudents(res);

                break;
            }
            case 'subTypeLecturers':
            {
                reporting.getLecturers(res);
                break;
            }
            case 'subTypeThreads':
            {
                switch (req.body.subTypeThreads)
                {
                    case 'allThreads':
                    {
                        reporting.getThreads(res);
                        break;
                    }
                    case 'spaceThreads':
                    {
                        reporting.getThreadsBy(0,res);
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
                break;
            }
            default:
            {
                break;
            }
        }
        //res.render('content/reportsMainsVersion', {
        //    title : 'Reporting'
        //})
        next();
    });

    // STATUS ------------------------------------------------------

    router.get('/addAppraisalType', function(req, res){

        res.render('content/addAppraisalType', {
            title : "New Appraisal Type"
        });
    });

    return router;
};
