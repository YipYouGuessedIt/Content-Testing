var levelCount = 2;

function addAppraisalLevel() {
    $('#appraisal_levels').append(
        "<tr>" +
        "<td>Level " + levelCount + "</td>" +
        "<td><input type='text' name='appraisal_name_level_" + levelCount + "' placeholder='e.g. Funny'></td>" +
        "<td><input type='number' name='appraisal_rating_level_" + levelCount + "' value='"+ levelCount +"'></td>" +
        "<td><input type='file' name='appraisal_icon_level_" + levelCount + "'></td>" +
        "</tr>");
    ++levelCount;
    return false;
}