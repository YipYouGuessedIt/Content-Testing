/**
 * Created by Abrie on 2015/04/09.
 */
var unit = require('unit.js');

describe("Content Integration Test Suite", function(){
    it('should pass', function(end){
       end();
    });
});